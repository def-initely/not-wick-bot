# Not Wick

Not Wick is a sarcastic Discord bot with joke moderation commands, fun utilities, community tools, and personality-driven replies.

## Run & Operate

- `pnpm run start:bot` — build and start the standalone Discord bot
- `pnpm --filter @workspace/api-server run dev` — run the combined Express API and Discord bot service
- `pnpm run typecheck` — full typecheck across all packages
- `pnpm run build` — typecheck + build all packages and both server entry points
- `pnpm --filter @workspace/api-spec run codegen` — regenerate API hooks and Zod schemas from the OpenAPI spec
- `pnpm --filter @workspace/db run push` — push DB schema changes (dev only)
- Standalone bot environment: `DISCORD_BOT_TOKEN` (required), `LOG_LEVEL` (optional)
- Combined API environment: `PORT` (required), `NODE_ENV` (optional), `DATABASE_URL` only if database-backed routes are enabled
- Copy `.env.example` to `.env` for a non-Replit deployment. Never commit `.env`.

## Stack

- pnpm workspaces, Node.js 20+, TypeScript 5.9
- Bot: Discord.js 14 with the Discord Gateway
- API: Express 5
- DB: PostgreSQL + Drizzle ORM
- Validation: Zod (`zod/v4`), `drizzle-zod`
- API codegen: Orval (from OpenAPI spec)
- Build: esbuild (ESM bundles)

## Where things live

- `artifacts/api-server/src/not-wick/` — Not Wick command registry, command groups, response pools, and Discord startup
- `artifacts/api-server/src/index.ts` — starts the combined HTTP API and Discord client
- `artifacts/api-server/src/not-wick-entry.ts` — standalone bot-only entry point
- `artifacts/api-server/dist/not-wick-entry.mjs` — generated bot runtime entry after build
- `lib/api-spec/openapi.yaml` — API contract source of truth

## Architecture decisions

- Fake moderation and security commands only send randomized jokes; they never call Discord moderation APIs.
- `nw!` parsing is case-insensitive while preserving the original argument text for commands such as `say`.
- The unsolicited chat personality has a per-channel cooldown so it remains uncommon.

## Product

Not Wick responds to `nw!` commands for fake moderation/security, games, facts, community information, permission-checked announcements, and personality replies. It also occasionally posts an unsolicited sarcastic comment in active guild channels.

## Deployment portability

- The bot source and all command modules are contained under `artifacts/api-server/src/not-wick/`.
- The portable start command is `pnpm run start:bot`; it does not start Express and does not require the database.
- Replit-specific behavior is limited to artifact workflow metadata in `.replit-artifact/artifact.toml`, Replit Secrets during development, and workspace tooling. The bot runtime itself uses standard Node.js, environment variables, Discord.js, and Pino.

## User preferences

_Populate as you build — explicit user instructions worth remembering across sessions._

## Gotchas

_Populate as you build — sharp edges, "always run X before Y" rules._

## Pointers

- See the `pnpm-workspace` skill for workspace structure, TypeScript setup, and package details
